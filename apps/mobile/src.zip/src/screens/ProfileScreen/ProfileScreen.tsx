// ═══════════════════════════════════════════════════════════════════════════
// FILE: src/screens/ProfileScreen/ProfileScreen.tsx
//
// Role-aware profile screen:
//   citizen  → blue theme + ProfileMenu
//   responder → red theme + ResponderProfileMenu
// ═══════════════════════════════════════════════════════════════════════════

import React, { useState, useEffect } from 'react';
import { SafeAreaView, StatusBar, StyleSheet, View, TouchableOpacity } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { ProfileMenu }          from '@organisms/ProfileMenu';
import { ResponderProfileMenu } from '@organisms/ResponderProfileMenu';
import { Text }   from '@atoms/Text';
import { colors } from '@theme/colors';
import { spacing } from '@theme/spacing';
import { authService } from '@services';
import Svg, { Path } from 'react-native-svg';

const RED = '#DC2626';

export const ProfileScreen: React.FC = () => {
  const navigation  = useNavigation<any>();
  const [userName, setUserName]     = useState('');
  const [userPhone, setUserPhone]   = useState('');
  const [userInitials, setUserInitials] = useState('');
  const [alertCount, setAlertCount] = useState(0);
  const [isResponder, setIsResponder] = useState(false);
  const [responderData, setResponderData] = useState<any>(null);
  const [missionCount, setMissionCount] = useState(0);

  useEffect(() => { loadUserData(); }, []);

  const loadUserData = async () => {
    try {
      const role = await AsyncStorage.getItem('@auth/user_role');
      const user = await authService.getStoredUser() as any;

      if (!user) return;

      const name = user.full_name || user.name || 'User';
      const initials = name.split(' ').map((n: string) => n[0]).join('').toUpperCase().slice(0, 2);
      setUserName(name);
      setUserInitials(initials);

      if (role === 'responder') {
        setIsResponder(true);
        setResponderData(user);
        setUserPhone(user.phone_number || '');
        // Load mission count
        try {
          const { authRequest, getUserUnitInfo } = require('@services/authService');
          const { unitId } = await getUserUnitInfo();
          if (unitId) {
            const data = await authRequest(`/deployments/unit/${unitId}/active`);
            setMissionCount(data?.count ?? (data?.missions?.length ?? 0));
          }
        } catch {}
      } else {
        setUserPhone(user.phone_number || '');
        // Load unread notification count
        try {
          const { notificationStore } = require('@services/notificationStore');
          setAlertCount(await notificationStore.unreadCount());
        } catch {}
      }
    } catch (e) {
      console.error('[ProfileScreen] loadUserData failed:', e);
    }
  };

  const handleNavigate = (screen: string) => {
    navigation.navigate(screen as never);
  };

  const handleLogout = async () => {
    await authService.logout();
  };

  const headerColor = isResponder ? RED : colors.primary;

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar barStyle="light-content" backgroundColor={headerColor} />

      <View style={[styles.header, { backgroundColor: headerColor }]}>
        <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
          <Svg width={24} height={24} viewBox="0 0 24 24" fill="none">
            <Path d="M19 12H5M12 19l-7-7 7-7"
              stroke={colors.white} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          </Svg>
        </TouchableOpacity>
        <Text variant="h4" style={styles.headerTitle}>
          {isResponder ? 'Responder Profile' : 'My Profile'}
        </Text>
        <View style={styles.placeholder} />
      </View>

      {isResponder && responderData ? (
        <ResponderProfileMenu
          name={responderData.full_name ?? userName}
          email={responderData.email ?? ''}
          role={responderData.role ?? 'staff'}
          department={responderData.department ?? 'fire'}
          employeeId={responderData.employee_id}
          initials={userInitials}
          missionCount={missionCount}
          onNavigate={handleNavigate}
          onLogout={handleLogout}
        />
      ) : (
        <ProfileMenu
          name={userName}
          phone={userPhone}
          role="Citizen"
          initials={userInitials}
          alertCount={alertCount}
          onNavigate={handleNavigate}
          onLogout={handleLogout}
        />
      )}
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safe:        { flex: 1, backgroundColor: colors.white },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: spacing.md, paddingVertical: spacing.sm,
  },
  backButton:  { width: 40, height: 40, alignItems: 'center', justifyContent: 'center' },
  headerTitle: { color: colors.white, fontWeight: '600' },
  placeholder: { width: 40 },
});

export default ProfileScreen;