// ═══════════════════════════════════════════════════════════════════════════
// FILE: src/screens/AlertsScreen/AlertsScreen.tsx
// ═══════════════════════════════════════════════════════════════════════════

import React, { useState, useEffect, useCallback } from 'react';
import {
  View, StyleSheet, SafeAreaView, StatusBar, TouchableOpacity,
  ActivityIndicator, Linking, Alert as RNAlert,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { AlertsList } from '@organisms/AlertsList';
import { Text } from '@/components/atoms/Text';
import { colors } from '@theme/colors';
import { spacing } from '@theme/spacing';
import Svg, { Path } from 'react-native-svg';
import type { Alert } from '../../types/disaster';
import { authRequest } from '@services/authService';

type Tab = 'all' | 'critical' | 'my_area';

export const AlertsScreen: React.FC = () => {
  const navigation = useNavigation<any>();
  const [tab, setTab] = useState<Tab>('all');
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => { loadAlerts(); }, []);

  const loadAlerts = async () => {
    try {
      setLoading(true);
      const data = await authRequest<any>('/live-map/disasters?bounds=53.2,-6.45,53.45,-6.05');
      const arr: any[] = Array.isArray(data) ? data : (data?.disasters ?? []);
      const mapped: Alert[] = arr.map((d: any) => ({
        id:           d.id ?? d.disaster_id ?? String(Math.random()),
        type:         severityToType(d.severity),
        severity:     (d.severity ?? 'LOW').toLowerCase() as Alert['severity'],
        title:        `${(d.disaster_type ?? d.type ?? 'Incident').replace(/_/g, ' ')} — ${d.location?.address ?? d.location_address ?? 'Dublin'}`,
        disasterType: d.disaster_type ?? d.type ?? 'OTHER',
        message:      buildDescription(d),
        location: {
          latitude:  d.location?.lat ?? 53.3498,
          longitude: d.location?.lon ?? -6.2603,
          name:      d.location?.address ?? d.location_address ?? 'Dublin, Ireland',
        },
        distance: '—',
        issuedAt: d.created_at ? new Date(d.created_at) : new Date(),
        isRead:   false,
      }));
      setAlerts(mapped);
    } catch (err) {
      console.error('Failed to load alerts:', err);
      setAlerts([]);
    } finally {
      setLoading(false);
    }
  };

  const severityToType = (severity: string): Alert['type'] => {
    const s = (severity ?? '').toUpperCase();
    if (s === 'CRITICAL' || s === 'HIGH') return 'evacuation';
    if (s === 'MEDIUM') return 'warning';
    return 'advisory';
  };

  const buildDescription = (d: any): string => {
    const parts: string[] = [];
    if (d.people_affected) parts.push(`${d.people_affected} people affected`);
    if (d.trigger_evacuation) parts.push('Evacuation triggered');
    const services = d.recommended_services ?? d.assigned_department;
    if (services) parts.push(`Response: ${Array.isArray(services) ? services.join(', ') : services}`);
    return parts.join(' · ') || 'Active emergency — stay alert';
  };

  // ── Handlers ────────────────────────────────────────────────────────────

  const handleViewDetails = useCallback((id: string) => {
    const alert = alerts.find((a) => a.id === id);
    if (!alert) return;
    navigation.navigate('AlertDetail', { alert });
  }, [alerts, navigation]);

  const handleGetDirections = useCallback(async (id: string) => {
    const alert = alerts.find((a) => a.id === id);
    if (!alert) return;
    const { latitude, longitude } = alert.location;
    const appleUrl  = `maps://app?daddr=${latitude},${longitude}`;
    const googleUrl = `https://www.google.com/maps/dir/?api=1&destination=${latitude},${longitude}`;
    try {
      const canApple = await Linking.canOpenURL(appleUrl);
      await Linking.openURL(canApple ? appleUrl : googleUrl);
    } catch {
      RNAlert.alert('Maps unavailable', 'Could not open directions.');
    }
  }, [alerts]);

  // ── Filtering ────────────────────────────────────────────────────────────

  const filtered = alerts.filter((a) => {
    if (tab === 'critical') return a.severity === 'critical';
    if (tab === 'my_area') { const d = parseFloat(a.distance); return !isNaN(d) && d <= 1; }
    return true;
  });
  const critCount   = alerts.filter((a) => a.severity === 'critical').length;
  const myAreaCount = alerts.filter((a) => { const d = parseFloat(a.distance); return !isNaN(d) && d <= 1; }).length;
  const tabs: { key: Tab; label: string; count: number }[] = [
    { key: 'all',      label: 'All',      count: alerts.length },
    { key: 'critical', label: 'Critical', count: critCount },
    { key: 'my_area',  label: 'My Area',  count: myAreaCount },
  ];

  // ── Render ───────────────────────────────────────────────────────────────

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar barStyle="dark-content" backgroundColor={colors.white} />

      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity style={styles.headerBtn} onPress={() => navigation.goBack()}>
          <Svg width={24} height={24} viewBox="0 0 24 24" fill="none">
            <Path d="M19 12H5M12 19l-7-7 7-7" stroke={colors.textPrimary} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          </Svg>
        </TouchableOpacity>
        <Text variant="h4" color="textPrimary">Active Alerts</Text>
        <TouchableOpacity style={styles.headerBtn} onPress={loadAlerts}>
          <Text variant="bodyMedium" color="primary">Refresh</Text>
        </TouchableOpacity>
      </View>

      {/* Tabs */}
      <View style={styles.tabBar}>
        {tabs.map((t) => (
          <TouchableOpacity
            key={t.key}
            style={[styles.tab, tab === t.key && styles.tabActive]}
            onPress={() => setTab(t.key)}
          >
            <Text
              variant="bodyMedium"
              color={tab === t.key ? 'primary' : 'textSecondary'}
              style={tab === t.key ? styles.activeTabText : undefined}
            >
              {t.label} ({t.count})
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* Content */}
      {loading ? (
        <View style={styles.center}>
          <ActivityIndicator size="large" color={colors.primary} />
          <Text variant="bodyMedium" color="textSecondary" style={{ marginTop: spacing.md }}>
            Loading alerts...
          </Text>
        </View>
      ) : filtered.length === 0 ? (
        <View style={styles.center}>
          <Svg width={64} height={64} viewBox="0 0 24 24" fill="none">
            <Path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5" stroke={colors.textSecondary} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          </Svg>
          <Text variant="h4" color="textSecondary" style={{ marginTop: spacing.lg }}>No Active Alerts</Text>
          <Text variant="bodyMedium" color="textSecondary" style={{ marginTop: spacing.sm, textAlign: 'center' }}>
            You'll be notified when there are emergencies in your area
          </Text>
        </View>
      ) : (
        <AlertsList
          alerts={filtered}
          onViewDetails={handleViewDetails}
          onGetDirections={handleGetDirections}
        />
      )}
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.background },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: spacing.lg, paddingVertical: spacing.md,
    backgroundColor: colors.white, borderBottomWidth: 1, borderBottomColor: colors.gray200,
  },
  headerBtn: { width: 60, height: 40, alignItems: 'center', justifyContent: 'center' },
  tabBar: {
    flexDirection: 'row', backgroundColor: colors.white,
    paddingHorizontal: spacing.md, borderBottomWidth: 1, borderBottomColor: colors.gray200,
  },
  tab: { flex: 1, paddingVertical: spacing.md, alignItems: 'center', borderBottomWidth: 2, borderBottomColor: 'transparent' },
  tabActive: { borderBottomColor: colors.primary },
  activeTabText: { fontWeight: '600' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center', paddingHorizontal: spacing.xl },
});

export default AlertsScreen;