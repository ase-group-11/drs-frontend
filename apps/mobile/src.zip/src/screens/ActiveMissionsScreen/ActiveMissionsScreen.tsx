// ═══════════════════════════════════════════════════════════════════════════
// FILE: src/screens/ActiveMissionsScreen/ActiveMissionsScreen.tsx
//
// Feature 2 — Active Missions Screen
// - GET /deployments/unit/{unit_id}/active on open
// - Tap mission → Mission Detail
// - Navigate to Disaster → sends coordinates to map (no reroute/status call)
// - Update Status → POST /deployments/{id}/update-status
// - SafeAreaView from react-native-safe-area-context (Android safe)
// ═══════════════════════════════════════════════════════════════════════════

import React, { useState, useEffect } from 'react';
import {
  View, ScrollView, StyleSheet, StatusBar, TouchableOpacity,
  ActivityIndicator, Alert, Linking, Modal, TextInput,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import { Text } from '@atoms/Text';
import { spacing, borderRadius } from '@theme/spacing';
import Svg, { Path } from 'react-native-svg';
import { authService, authRequest, getUserUnitInfo } from '@services/authService';
import { wsService } from '@services/wsService';
import { disasterStore, SEVERITY_COLOR } from '@services/disasterStore';
import { disasterService } from '@services/disasterService';

const RED = '#DC2626';

interface Mission {
  id: string;
  disaster_id: string;
  disaster_type: string;
  severity: string;
  location_address: string;
  coordinates: { lat: number; lon: number };
  status: string;
  assigned_at: string;
  distance_km: string;
  people_affected: string;
  eta_minutes: string;
  unit_id: string;
  unit_members: number;
}

const SEV_COLOR: Record<string, string> = { CRITICAL: '#ef4444', HIGH: '#f97316', MEDIUM: '#eab308', LOW: '#3b82f6' };
const STATUS_COLOR: Record<string, string> = { dispatched: '#DC2626', en_route: '#F97316', on_scene: '#8B5CF6', in_progress: '#EF4444', completed: '#22C55E', cancelled: '#6B7280' };
const TYPE_EMOJI: Record<string, string> = { FIRE: '🔥', FLOOD: '🌊', STORM: '⛈️', EARTHQUAKE: '🏚️', HURRICANE: '🌀', TORNADO: '🌪️', OTHER: '⚠️' };
const STATUS_OPTIONS = [
  { id: 'EN_ROUTE',    emoji: '🚗', label: 'En Route',    desc: 'Traveling to scene' },
  { id: 'ON_SCENE',    emoji: '📍', label: 'On Scene',    desc: 'Arrived at location' },
  { id: 'IN_PROGRESS', emoji: '⚡', label: 'In Progress', desc: 'Actively responding' },
  { id: 'COMPLETED',   emoji: '✅', label: 'Completed',   desc: 'Task finished' },
];

const formatAgo = (iso: string) => {
  const s = Math.floor((Date.now() - new Date(iso).getTime()) / 1000);
  if (s < 60) return 'just now';
  if (s < 3600) return `${Math.floor(s / 60)} mins ago`;
  return `${Math.floor(s / 3600)} hr ago`;
};

export const ActiveMissionsScreen: React.FC = () => {
  const navigation = useNavigation<any>();
  const [tab, setTab] = useState<'active' | 'completed'>('active');
  const [active, setActive] = useState<Mission[]>([]);
  const [completed, setCompleted] = useState<Mission[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [unitLabel, setUnitLabel] = useState('Unit');

  // Detail view
  const [selectedMission, setSelectedMission] = useState<Mission | null>(null);
  const [missionDetail, setMissionDetail] = useState<any>(null);
  const [detailLoading, setDetailLoading] = useState(false);

  // Status modal
  const [statusModal, setStatusModal] = useState<Mission | null>(null);
  const [selStatus, setSelStatus] = useState('');
  const [sitrep, setSitrep] = useState('');
  const [tags, setTags] = useState<string[]>([]);
  const [minorInjuries, setMinorInjuries] = useState(0);
  const [seriousInjuries, setSeriousInjuries] = useState(0);
  const [locationVerified, setLocationVerified] = useState(false);
  const [requestBackupFlag, setRequestBackupFlag] = useState(false);
  const [isFalseAlarm, setIsFalseAlarm] = useState(false);
  const [assessmentNotes, setAssessmentNotes] = useState('');
  const [submitting, setSubmitting] = useState(false);

  // WS
  useEffect(() => {
    wsService.connect(true);
    const unsub = wsService.onAlert((alert) => {
      if (['disaster.dispatched', 'disaster.verified', 'disaster.updated', 'disaster.resolved',
           'disaster.false_alarm', 'disaster.unit_completed', 'coordination.team_assigned'].includes(alert.event_type)) {
        fetchMissions();
      }
      if (alert.event_type === 'disaster.resolved') {
        const did = alert.data?.disaster_id;
        if (did) setActive(prev => prev.filter(m => m.disaster_id !== did));
      }
      if (alert.event_type === 'disaster.false_alarm') {
        const did = alert.data?.disaster_id;
        if (did) setActive(prev => prev.filter(m => m.disaster_id !== did));
      }
      if (alert.event_type === 'disaster.backup_requested') {
        Alert.alert('🆘 BACKUP REQUESTED', `${alert.title}\n\n${alert.message}`, [{ text: 'OK' }]);
      }
      if (alert.event_type === 'coordination.escalation') {
        Alert.alert('🚨 ESCALATION', alert.message, [{ text: 'OK' }]);
      }
      if (alert.event_type === 'evacuation.triggered') {
        Alert.alert('🚨 EVACUATION', alert.message ?? 'Evacuation triggered.',
          [{ text: 'View Plans', onPress: () => navigation.navigate('EvacuationPlans' as any) }, { text: 'OK' }]);
      }
    });
    return () => { unsub(); wsService.disconnect(); };
  }, []);

  useEffect(() => { fetchMissions(); }, []);

  const fetchMissions = async () => {
    setLoading(true);
    try {
      const user = await authService.getStoredUser();
      if (!user?.id) { setLoading(false); return; }

      // Get unit ID from /users/{user_id} API
      const { unitId, unitCodes } = await getUserUnitInfo();
      const unitCode = unitCodes.length > 0 ? unitCodes[0] : 'Unit';

      setUnitLabel(unitCode);
      if (!unitId) { setLoading(false); return; }

      const [a, c] = await Promise.all([
        authRequest<any>(`/deployments/unit/${unitId}/active`),
        authRequest<any>(`/deployments/unit/${unitId}/completed?limit=20`),
      ]);

      const toM = (m: any): Mission => ({
        id: m.id ?? m.deployment_id,
        disaster_id: m.disaster_id ?? m.disaster?.id ?? m.id,
        disaster_type: (m.disaster?.disaster_type ?? m.disaster?.type ?? m.disaster_type ?? 'OTHER').toUpperCase(),
        severity: (m.disaster?.severity ?? m.severity ?? 'MEDIUM').toUpperCase(),
        location_address: m.disaster?.location_address ?? m.location_address ?? 'Unknown',
        coordinates: m.disaster?.location ?? m.disaster?.coordinates ?? { lat: 53.3498, lon: -6.2603 },
        status: (m.deployment_status ?? m.status ?? 'dispatched').toLowerCase(),
        assigned_at: m.assigned_at ?? m.timeline?.dispatched_at ?? m.created_at ?? new Date().toISOString(),
        distance_km: m.distance_km ? String(m.distance_km) : '—',
        people_affected: m.disaster?.people_affected ? String(m.disaster.people_affected) : '—',
        eta_minutes: m.eta_minutes ? String(m.eta_minutes) : '—',
        unit_id: m.unit_id ?? unitCode,
        unit_members: m.unit_members ?? 4,
      });

      const activeList = a?.active_missions ?? a?.missions ?? (Array.isArray(a) ? a : []);
      const completedList = c?.completed_missions ?? c?.missions ?? (Array.isArray(c) ? c : []);
      setActive(activeList.map(toM));
      setCompleted(completedList.map(toM));
      disasterStore.setActiveMissions(activeList);
    } catch (e: any) {
      setError(e.message || 'Could not load missions.');
    }
    setLoading(false);
  };

  const openDetail = async (m: Mission) => {
    setSelectedMission(m);
    setDetailLoading(true);
    try {
      const detail = await disasterService.getDeploymentDetail(m.id);
      setMissionDetail(detail);
    } catch { setMissionDetail(null); }
    setDetailLoading(false);
  };

  // Navigate — just fly to coordinates, no reroute/status (avoids 422)
  const navigateToDisaster = (m: Mission) => {
    navigation.navigate('Home' as any, {
      flyToLat: m.coordinates.lat,
      flyToLon: m.coordinates.lon,
      flyToLabel: m.location_address,
    });
  };

  const openStatusModal = (m: Mission) => {
    setStatusModal(m);
    setSelStatus(''); setSitrep(''); setTags([]); setMinorInjuries(0);
    setSeriousInjuries(0); setLocationVerified(false); setRequestBackupFlag(false);
    setIsFalseAlarm(false); setAssessmentNotes('');
  };

  const submitStatus = async () => {
    if (!selStatus || !statusModal) return;
    setSubmitting(true);
    try {
      await disasterService.updateDeploymentStatus(statusModal.id, {
        new_status: selStatus,
        situation_report: sitrep || undefined,
        tags: tags.length > 0 ? tags : undefined,
        minor_injuries: minorInjuries,
        serious_injuries: seriousInjuries,
        location_verified: locationVerified,
        request_immediate_backup: requestBackupFlag,
        assessment_notes: assessmentNotes || undefined,
        is_false_alarm: isFalseAlarm,
      });
      Alert.alert('✅ Status Updated', `Status: ${selStatus.replace(/_/g, ' ')}`);
      const sl = selStatus.toLowerCase();
      if (sl === 'completed' || isFalseAlarm) {
        setActive(prev => prev.filter(x => x.id !== statusModal.id));
        disasterStore.removeMission(statusModal.id);
      } else {
        setActive(prev => prev.map(x => x.id === statusModal.id ? { ...x, status: sl } : x));
        disasterStore.updateMissionStatus(statusModal.id, selStatus);
      }
      setStatusModal(null);
    } catch (e: any) {
      Alert.alert('Error', e.message || 'Failed to update status.');
    }
    setSubmitting(false);
  };

  const list = tab === 'active' ? active : completed;

  // ═══ MISSION DETAIL VIEW ═══════════════════════════════════════════
  if (selectedMission) {
    const m = selectedMission;
    const sevCol = SEV_COLOR[m.severity] ?? '#6B7280';

    return (
      <SafeAreaView style={S.safe} edges={['top', 'left', 'right']}>
        <StatusBar barStyle="light-content" backgroundColor={RED} />
        <View style={S.header}>
          <TouchableOpacity style={S.hBtn} onPress={() => { setSelectedMission(null); setMissionDetail(null); }}>
            <Svg width={24} height={24} viewBox="0 0 24 24" fill="none">
              <Path d="M19 12H5M12 19l-7-7 7-7" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
            </Svg>
          </TouchableOpacity>
          <Text style={S.hTitle}>Mission Detail</Text>
          <View style={{ width: 40 }} />
        </View>
        <ScrollView contentContainerStyle={{ padding: spacing.md }}>
          <View style={[S.card, { borderLeftWidth: 4, borderLeftColor: sevCol }]}>
            <Text style={{ fontSize: 28, lineHeight: 36 }}>{TYPE_EMOJI[m.disaster_type] ?? '⚠️'}</Text>
            <Text style={{ fontSize: 17, lineHeight: 24, fontWeight: '700', color: '#1F2937', marginTop: 4 }}>
              {m.disaster_type.replace(/_/g, ' ')} — {m.severity}
            </Text>
            <Text style={{ fontSize: 13, color: '#6B7280', marginTop: 4 }}>{m.location_address}</Text>
            <Text style={{ fontSize: 12, color: '#9CA3AF', marginTop: 2 }}>Assigned {formatAgo(m.assigned_at)}</Text>
            <View style={[S.statusBadge, { backgroundColor: STATUS_COLOR[m.status] ?? '#6B7280', alignSelf: 'flex-start', marginTop: 8 }]}>
              <Text style={S.statusBadgeTxt}>{m.status.replace(/_/g, ' ').toUpperCase()}</Text>
            </View>
          </View>

          {detailLoading ? <ActivityIndicator color={RED} style={{ margin: 20 }} /> : missionDetail ? (
            <View style={S.card}>
              <Text style={{ fontSize: 14, fontWeight: '700', color: '#1F2937', marginBottom: 8 }}>Deployment Details</Text>
              {missionDetail.priority_level && <Text style={S.infoRow}>Priority: <Text style={S.infoVal}>{missionDetail.priority_level}</Text></Text>}
              {missionDetail.situation_report && <Text style={S.infoRow}>Sitrep: <Text style={S.infoVal}>{missionDetail.situation_report}</Text></Text>}
              {missionDetail.timeline && Object.entries(missionDetail.timeline).map(([k, v]) => v ? (
                <Text key={k} style={S.infoRow}>{k.replace(/_/g, ' ')}: <Text style={S.infoVal}>{new Date(v as string).toLocaleTimeString()}</Text></Text>
              ) : null)}
            </View>
          ) : null}

          <View style={{ gap: spacing.sm, marginTop: spacing.md }}>
            <TouchableOpacity style={S.btnRed} onPress={() => navigateToDisaster(m)}>
              <Text style={S.btnRedTxt}>🧭  Navigate to Disaster</Text>
            </TouchableOpacity>
            <TouchableOpacity style={S.btnOutline} onPress={() => openStatusModal(m)}>
              <Text style={S.btnOutTxt}>📱  Update Status</Text>
            </TouchableOpacity>
            <TouchableOpacity style={S.btnOutline}
              onPress={() => Alert.alert('📞 Contact Command', 'Call HQ?',
                [{ text: 'Cancel', style: 'cancel' }, { text: 'Call', onPress: () => Linking.openURL('tel:999') }])}>
              <Text style={S.btnOutTxt}>📞  Contact Command</Text>
            </TouchableOpacity>
          </View>
          <View style={{ height: 60 }} />
        </ScrollView>
        {renderStatusModal()}
      </SafeAreaView>
    );
  }

  // ═══ MISSION LIST VIEW ═════════════════════════════════════════════
  function renderStatusModal() {
    return (
      <Modal visible={!!statusModal} transparent animationType="slide" onRequestClose={() => setStatusModal(null)}>
        <View style={S.overlay}>
          <View style={S.modalCard}>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: spacing.lg }}>
              <Text style={{ fontSize: 18, lineHeight: 24, fontWeight: '700' }}>Update Status</Text>
              <TouchableOpacity onPress={() => setStatusModal(null)}>#<Text style={{ fontSize: 22, lineHeight: 28, color: '#9CA3AF' }}>✕</Text></TouchableOpacity>
            </View>
            <ScrollView showsVerticalScrollIndicator={false}>
              {STATUS_OPTIONS.map(opt => (
                <TouchableOpacity key={opt.id} style={[S.statusOpt, selStatus === opt.id && S.statusOptOn]}
                  onPress={() => setSelStatus(opt.id)}>
                  <Text style={{ fontSize: 24, lineHeight: 32, marginRight: 12 }}>{opt.emoji}</Text>
                  <View style={{ flex: 1 }}>
                    <Text style={{ fontWeight: selStatus === opt.id ? '700' : '400', fontSize: 15 }}>{opt.label}</Text>
                    <Text style={{ fontSize: 13, color: '#6B7280' }}>{opt.desc}</Text>
                  </View>
                </TouchableOpacity>
              ))}

              <Text style={S.fieldLabel}>Situation Report</Text>
              <TextInput style={S.sitrep} placeholder="Describe situation..." placeholderTextColor="#9CA3AF"
                value={sitrep} onChangeText={setSitrep} multiline maxLength={500} textAlignVertical="top" />

              <Text style={S.fieldLabel}>Tags</Text>
              <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginBottom: 8 }}>
                {['flood', 'fire', 'vehicles-trapped', 'building-damage', 'road-blocked', 'hazmat', 'medical', 'rescue'].map(tag => (
                  <TouchableOpacity key={tag} style={[S.tagChip, tags.includes(tag) && S.tagChipOn]}
                    onPress={() => setTags(p => p.includes(tag) ? p.filter(t => t !== tag) : [...p, tag])}>
                    <Text style={[S.tagTxt, tags.includes(tag) && S.tagTxtOn]}>{tag}</Text>
                  </TouchableOpacity>
                ))}
              </View>

              <View style={{ flexDirection: 'row', gap: 12, marginTop: 8 }}>
                <View style={{ flex: 1 }}>
                  <Text style={{ fontSize: 12, color: '#6B7280', marginBottom: 4 }}>Minor Injuries</Text>
                  <View style={S.counterRow}>
                    <TouchableOpacity style={S.cBtn} onPress={() => setMinorInjuries(Math.max(0, minorInjuries - 1))}><Text style={S.cBtnTxt}>−</Text></TouchableOpacity>
                    <Text style={S.cVal}>{minorInjuries}</Text>
                    <TouchableOpacity style={[S.cBtn, { backgroundColor: RED }]} onPress={() => setMinorInjuries(minorInjuries + 1)}><Text style={[S.cBtnTxt, { color: '#fff' }]}>+</Text></TouchableOpacity>
                  </View>
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={{ fontSize: 12, color: '#6B7280', marginBottom: 4 }}>Serious Injuries</Text>
                  <View style={S.counterRow}>
                    <TouchableOpacity style={S.cBtn} onPress={() => setSeriousInjuries(Math.max(0, seriousInjuries - 1))}><Text style={S.cBtnTxt}>−</Text></TouchableOpacity>
                    <Text style={S.cVal}>{seriousInjuries}</Text>
                    <TouchableOpacity style={[S.cBtn, { backgroundColor: RED }]} onPress={() => setSeriousInjuries(seriousInjuries + 1)}><Text style={[S.cBtnTxt, { color: '#fff' }]}>+</Text></TouchableOpacity>
                  </View>
                </View>
              </View>

              <View style={{ marginTop: 12, gap: 8 }}>
                <CheckRow label="Location verified — I am on scene" checked={locationVerified} onToggle={() => setLocationVerified(v => !v)} color="#22C55E" />
                <CheckRow label="Request immediate backup" checked={requestBackupFlag} onToggle={() => setRequestBackupFlag(v => !v)} color="#F97316" />
              </View>

              {selStatus === 'ON_SCENE' && (
                <View style={[S.falseAlarmBox, isFalseAlarm && { borderColor: RED, backgroundColor: '#FEF2F2' }]}>
                  <CheckRow label="Mark as False Alarm" checked={isFalseAlarm} onToggle={() => setIsFalseAlarm(v => !v)} color={RED} />
                  <Text style={{ fontSize: 12, color: '#6B7280', marginTop: 2, marginLeft: 30 }}>No emergency found. This will close the disaster.</Text>
                </View>
              )}

              <Text style={S.fieldLabel}>Assessment Notes</Text>
              <TextInput style={[S.sitrep, { minHeight: 60 }]} placeholder="Additional observations..."
                placeholderTextColor="#9CA3AF" value={assessmentNotes} onChangeText={setAssessmentNotes} multiline maxLength={300} textAlignVertical="top" />

              <View style={{ flexDirection: 'row', gap: 12, marginTop: 20, marginBottom: 40 }}>
                <TouchableOpacity style={[S.modalBtn, { flex: 1, backgroundColor: '#F3F4F6' }]} onPress={() => setStatusModal(null)}>
                  <Text style={{ color: '#6B7280', fontWeight: '600' }}>Cancel</Text>
                </TouchableOpacity>
                <TouchableOpacity style={[S.modalBtn, { flex: 2, backgroundColor: selStatus ? RED : '#D1D5DB' }]}
                  onPress={submitStatus} disabled={!selStatus || submitting}>
                  {submitting ? <ActivityIndicator color="#fff" size="small" />
                    : <Text style={{ color: '#fff', fontWeight: '700' }}>{isFalseAlarm ? '⚠️ Report False Alarm' : 'Submit Update'}</Text>}
                </TouchableOpacity>
              </View>
            </ScrollView>
          </View>
        </View>
      </Modal>
    );
  }

  return (
    <SafeAreaView style={S.safe} edges={['top', 'left', 'right']}>
      <StatusBar barStyle="light-content" backgroundColor={RED} />
      <View style={S.header}>
        <TouchableOpacity style={S.hBtn} onPress={() => navigation.goBack()}>
          <Svg width={24} height={24} viewBox="0 0 24 24" fill="none">
            <Path d="M19 12H5M12 19l-7-7 7-7" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          </Svg>
        </TouchableOpacity>
        <View style={{ alignItems: 'center' }}>
          <Text style={S.hTitle}>Active Missions</Text>
          <Text style={{ color: 'rgba(255,255,255,0.7)', fontSize: 11 }}>{unitLabel}</Text>
        </View>
        <TouchableOpacity style={S.hBtn} onPress={fetchMissions}>
          {loading ? <ActivityIndicator color="#fff" size="small" /> : <Text style={{ color: '#fff', fontSize: 20, lineHeight: 26 }}>↻</Text>}
        </TouchableOpacity>
      </View>

      <View style={S.tabs}>
        {(['active', 'completed'] as const).map(k => (
          <TouchableOpacity key={k} style={[S.tab, tab === k && S.tabOn]} onPress={() => setTab(k)}>
            <Text style={[S.tabTxt, tab === k && S.tabTxtOn]}>{k === 'active' ? `Active (${active.length})` : `Done (${completed.length})`}</Text>
          </TouchableOpacity>
        ))}
      </View>

      {!!error && (
        <View style={{ backgroundColor: '#FEE2E2', margin: 12, padding: 14, borderRadius: 10, borderLeftWidth: 3, borderLeftColor: RED }}>
          <Text style={{ color: '#991B1B', fontSize: 13 }}>{error}</Text>
          <TouchableOpacity onPress={fetchMissions}><Text style={{ color: RED, fontWeight: '700', marginTop: 6 }}>Retry</Text></TouchableOpacity>
        </View>
      )}

      <ScrollView contentContainerStyle={{ padding: spacing.md }}>
        {list.length === 0 ? (
          <View style={{ alignItems: 'center', paddingTop: 80 }}>
            <Text style={{ fontSize: 48, lineHeight: 62 }}>{tab === 'active' ? '✅' : '📋'}</Text>
            <Text style={{ fontSize: 16, color: '#6B7280', marginTop: 12 }}>{tab === 'active' ? 'No active missions' : 'No completed missions'}</Text>
          </View>
        ) : list.map(m => (
          <TouchableOpacity key={m.id} style={[S.card, { borderLeftWidth: 4, borderLeftColor: SEV_COLOR[m.severity] ?? '#6B7280' }]}
            onPress={() => openDetail(m)} activeOpacity={0.8}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 4 }}>
              <Text style={{ fontSize: 11, color: '#9CA3AF', fontWeight: '600' }}>#{m.disaster_id?.slice(0, 8)}</Text>
              <View style={{ paddingHorizontal: 8, paddingVertical: 2, borderRadius: 4, backgroundColor: SEV_COLOR[m.severity] ?? '#6B7280' }}>
                <Text style={{ color: '#fff', fontSize: 10, fontWeight: '800' }}>{m.severity}</Text>
              </View>
            </View>
            <Text style={{ fontSize: 17, lineHeight: 24, fontWeight: '700', color: '#1F2937' }}>{TYPE_EMOJI[m.disaster_type] ?? '⚠️'}  {m.disaster_type.replace(/_/g, ' ')}</Text>
            <Text style={{ fontSize: 13, color: '#6B7280' }}>{m.location_address}</Text>
            <Text style={{ fontSize: 12, color: '#9CA3AF', marginTop: 2 }}>Assigned {formatAgo(m.assigned_at)}</Text>
            <View style={[S.statusBadge, { backgroundColor: STATUS_COLOR[m.status] ?? '#6B7280', alignSelf: 'flex-start', marginTop: 8 }]}>
              <Text style={S.statusBadgeTxt}>{m.status.replace(/_/g, ' ').toUpperCase()}</Text>
            </View>
          </TouchableOpacity>
        ))}
        <View style={{ height: 60 }} />
      </ScrollView>
      {renderStatusModal()}
    </SafeAreaView>
  );
};

const CheckRow: React.FC<{ label: string; checked: boolean; onToggle: () => void; color: string }> = ({ label, checked, onToggle, color }) => (
  <TouchableOpacity style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }} onPress={onToggle}>
    <View style={{ width: 22, height: 22, borderRadius: 6, borderWidth: 2, borderColor: checked ? color : '#D1D5DB', backgroundColor: checked ? color : 'transparent', justifyContent: 'center', alignItems: 'center' }}>
      {checked && <Text style={{ color: '#fff', fontSize: 10 }}>✓</Text>}
    </View>
    <Text style={{ flex: 1, fontSize: 14, color: '#374151' }}>{label}</Text>
  </TouchableOpacity>
);

const S = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#F8FAFC' },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: spacing.md, paddingVertical: spacing.md, backgroundColor: RED },
  hBtn: { width: 40, height: 40, justifyContent: 'center', alignItems: 'center' },
  hTitle: { color: '#fff', fontSize: 18, lineHeight: 24, fontWeight: '700' },
  tabs: { flexDirection: 'row', backgroundColor: '#fff', borderBottomWidth: 1, borderBottomColor: '#E5E7EB' },
  tab: { flex: 1, paddingVertical: 14, alignItems: 'center', borderBottomWidth: 3, borderBottomColor: 'transparent' },
  tabOn: { borderBottomColor: RED },
  tabTxt: { fontSize: 14, color: '#6B7280', fontWeight: '500' },
  tabTxtOn: { color: RED, fontWeight: '700' },
  card: { backgroundColor: '#fff', borderRadius: 12, marginBottom: 10, padding: 14, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.07, shadowRadius: 6, elevation: 3 },
  statusBadge: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 6 },
  statusBadgeTxt: { color: '#fff', fontSize: 12, fontWeight: '700' },
  infoRow: { fontSize: 13, color: '#6B7280', marginBottom: 4 },
  infoVal: { color: '#1F2937', fontWeight: '600' },
  btnRed: { backgroundColor: RED, borderRadius: 10, paddingVertical: 14, alignItems: 'center' },
  btnRedTxt: { color: '#fff', fontWeight: '700', fontSize: 14 },
  btnOutline: { borderWidth: 1.5, borderColor: '#E5E7EB', borderRadius: 10, paddingVertical: 14, alignItems: 'center', backgroundColor: '#fff' },
  btnOutTxt: { color: '#374151', fontWeight: '600', fontSize: 14 },
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.45)', justifyContent: 'flex-end' },
  modalCard: { backgroundColor: '#fff', borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 20, maxHeight: '92%' },
  modalBtn: { paddingVertical: 14, borderRadius: 10, alignItems: 'center' },
  statusOpt: { flexDirection: 'row', alignItems: 'center', padding: 12, borderRadius: 10, marginBottom: 8, borderWidth: 1.5, borderColor: '#E5E7EB' },
  statusOptOn: { borderColor: RED, backgroundColor: '#FFF5F5' },
  fieldLabel: { fontSize: 14, fontWeight: '700', color: '#374151', marginTop: 16, marginBottom: 8 },
  sitrep: { minHeight: 100, borderWidth: 1.5, borderColor: '#E5E7EB', borderRadius: 10, padding: 12, fontSize: 14, color: '#1F2937', backgroundColor: '#F9FAFB' },
  tagChip: { paddingHorizontal: 10, paddingVertical: 6, borderRadius: 16, borderWidth: 1.5, borderColor: '#E5E7EB', backgroundColor: '#F9FAFB' },
  tagChipOn: { borderColor: RED, backgroundColor: '#FEF2F2' },
  tagTxt: { fontSize: 12, fontWeight: '600', color: '#6B7280' },
  tagTxtOn: { color: RED },
  counterRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  cBtn: { width: 36, height: 36, borderRadius: 18, backgroundColor: '#F3F4F6', justifyContent: 'center', alignItems: 'center' },
  cBtnTxt: { fontSize: 18, lineHeight: 24, fontWeight: '700', color: '#374151' },
  cVal: { fontSize: 18, lineHeight: 24, fontWeight: '800', color: '#1F2937', minWidth: 32, textAlign: 'center' },
  falseAlarmBox: { marginTop: 12, padding: 12, borderRadius: 10, borderWidth: 1.5, borderColor: '#E5E7EB', backgroundColor: '#F9FAFB' },
});

export default ActiveMissionsScreen;