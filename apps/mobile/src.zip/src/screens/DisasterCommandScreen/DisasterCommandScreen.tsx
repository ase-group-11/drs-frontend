// ═══════════════════════════════════════════════════════════════════════════
// FILE: src/screens/DisasterCommandScreen/DisasterCommandScreen.tsx
//
// ERT Command View — STANDALONE SCREEN
// Reads from global disasterStore. No unnecessary API calls.
//   - Deployments fetched ONLY when user taps a disaster
//   - Removed reroute/status/{id} call (requires route_id → 422)
//   - Reroute plans via GET /reroute/plans (explicit button)
//   - Uses SafeAreaView from react-native-safe-area-context
// ═══════════════════════════════════════════════════════════════════════════

import React, { useState, useEffect } from 'react';
import {
  View, ScrollView, StyleSheet, StatusBar,
  TouchableOpacity, ActivityIndicator, Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import { Text } from '@atoms/Text';
import { spacing, borderRadius } from '@theme/spacing';
import Svg, { Path } from 'react-native-svg';
import { authRequest } from '@services/authService';
import { wsService } from '@services/wsService';
import { disasterStore, SEVERITY_COLOR } from '@services/disasterStore';
import type { WSAlert, ActiveDisaster } from '@services/disasterStore';

const RED = '#DC2626';

const STATUS_COLOR: Record<string, string> = {
  ACTIVE: '#EF4444', VERIFIED: '#F97316', DISPATCHED: '#3B82F6',
  PENDING: '#EAB308', RESOLVED: '#22C55E', REJECTED: '#6B7280',
};
const TYPE_EMOJI: Record<string, string> = {
  FIRE: '🔥', FLOOD: '🌊', STORM: '⛈️', EARTHQUAKE: '🏚️',
  HURRICANE: '🌀', EXPLOSION: '💥', GAS_LEAK: '☁️',
  ACCIDENT: '🚗', BUILDING_COLLAPSE: '🏚️', HAZMAT: '☣️', OTHER: '⚠️',
};

export const DisasterCommandScreen: React.FC = () => {
  const navigation = useNavigation<any>();

  // Subscribe to global store
  const [, forceRender] = useState(0);
  useEffect(() => {
    const unsub = disasterStore.subscribe(() => forceRender(n => n + 1));
    return unsub;
  }, []);
  const { activeDisasters, resolvedDisasters } = disasterStore.getState();

  // Local — detail loaded ONLY on tap
  const [selectedId, setSelectedId]         = useState<string | null>(null);
  const [deployments, setDeployments]       = useState<any[]>([]);
  const [allReroutePlans, setAllReroutePlans] = useState<any[]>([]);
  const [detailLoading, setDetailLoading]   = useState(false);
  const [rerouteLoading, setRerouteLoading] = useState(false);

  // WS alerts
  useEffect(() => {
    const unsub = wsService.onAlert((alert: WSAlert) => {
      if (alert.event_type === 'disaster.backup_requested') {
        Alert.alert('🆘 BACKUP REQUESTED', `${alert.title}\n\n${alert.message}`,
          [{ text: 'View Missions', onPress: () => navigation.navigate('ActiveMissions') }, { text: 'OK' }]);
      }
      if (alert.event_type === 'coordination.escalation') {
        Alert.alert('🚨 ESCALATION', alert.message, [{ text: 'OK' }]);
      }
      if (alert.event_type === 'evacuation.triggered') {
        Alert.alert('🚨 EVACUATION', alert.message ?? 'Evacuation plan activated.',
          [{ text: 'View Plans', onPress: () => navigation.navigate('EvacuationPlans' as any) }, { text: 'OK' }]);
      }
    });
    return () => unsub();
  }, []);

  // Fetch deployments ONLY when user taps — no auto-fetch
  const selectDisaster = async (d: ActiveDisaster) => {
    if (selectedId === d.id) { setSelectedId(null); setDeployments([]); return; }
    setSelectedId(d.id);
    setDeployments([]);
    setDetailLoading(true);
    try {
      const data = await authRequest<any>(`/disasters/${d.id}/deployments`);
      setDeployments(data?.deployments ?? (Array.isArray(data) ? data : []));
    } catch (e: any) {
      console.warn('[Command] Deployments failed:', e.message);
    }
    setDetailLoading(false);
  };

  // Reroute plans — explicit button only
  const loadReroutePlans = async () => {
    setRerouteLoading(true);
    try {
      const data = await authRequest<any[]>('/reroute/plans');
      setAllReroutePlans(Array.isArray(data) ? data : []);
    } catch { setAllReroutePlans([]); }
    setRerouteLoading(false);
  };

  const selectedDisaster = activeDisasters.find(d => d.id === selectedId);

  return (
    <SafeAreaView style={S.safe} edges={['top', 'left', 'right']}>
      <StatusBar barStyle="light-content" backgroundColor={RED} />

      <View style={S.header}>
        <TouchableOpacity style={S.hBtn} onPress={() => navigation.goBack()}>
          <Svg width={24} height={24} viewBox="0 0 24 24" fill="none">
            <Path d="M19 12H5M12 19l-7-7 7-7" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          </Svg>
        </TouchableOpacity>
        <Text style={S.headerTitle}>Command View</Text>
        <View style={{ width: 40 }} />
      </View>

      <ScrollView showsVerticalScrollIndicator={false}>
        {activeDisasters.length === 0 && resolvedDisasters.length === 0 ? (
          <View style={S.emptyCard}>
            <Text style={{ fontSize: 40, lineHeight: 52 }}>✅</Text>
            <Text style={S.emptyTitle}>No Active Disasters</Text>
            <Text style={S.emptySub}>Disasters appear here on disaster.evaluated events.</Text>
          </View>
        ) : (
          <>
            {activeDisasters.length > 0 && (
              <>
                <Text style={S.sectionLabel}>ACTIVE INCIDENTS ({activeDisasters.length})</Text>
                {activeDisasters.map(d => {
                  const sev = (d.severity ?? 'LOW').toUpperCase();
                  const col = SEVERITY_COLOR[sev] ?? '#6B7280';
                  const isSelected = d.id === selectedId;
                  return (
                    <View key={d.id}>
                      <TouchableOpacity style={[S.disasterCard, isSelected && S.cardSelected]}
                        onPress={() => selectDisaster(d)} activeOpacity={0.8}>
                        <View style={[S.sevBar, { backgroundColor: col }]} />
                        <Text style={{ fontSize: 26, lineHeight: 34, marginRight: 10 }}>{TYPE_EMOJI[d.type] ?? '⚠️'}</Text>
                        <View style={{ flex: 1 }}>
                          <View style={S.titleRow}>
                            <Text style={S.dtype}>{(d.type ?? '').replace(/_/g, ' ')}</Text>
                            <View style={[S.pill, { backgroundColor: col + '20' }]}>
                              <Text style={[S.pillTxt, { color: col }]}>{sev}</Text>
                            </View>
                            {d.disaster_status === 'DISPATCHED' && (
                              <View style={[S.pill, { backgroundColor: '#3B82F620' }]}>
                                <Text style={[S.pillTxt, { color: '#3B82F6' }]}>UNITS DISPATCHED</Text>
                              </View>
                            )}
                          </View>
                          <Text style={S.daddr}>{d.location_address}</Text>
                          <Text style={S.dmeta}>
                            {d.tracking_id}{d.people_affected > 0 ? ` · ${d.people_affected} affected` : ''}
                            {d.assigned_department ? ` · ${d.assigned_department}` : ''}
                          </Text>
                        </View>
                        <View style={[S.dot, { backgroundColor: STATUS_COLOR[d.disaster_status] ?? '#6B7280' }]} />
                      </TouchableOpacity>

                      {isSelected && (
                        <View style={S.detailBox}>
                          {detailLoading ? <ActivityIndicator color={RED} style={{ margin: 16 }} /> : (
                            <>
                              <View style={S.card}>
                                <Text style={S.cardTitle}>Incident Info</Text>
                                <Row label="Status" value={d.disaster_status} />
                                <Row label="Severity" value={d.severity} />
                                <Row label="Location" value={d.location_address} />
                                {d.people_affected > 0 && <Row label="Affected" value={`${d.people_affected}`} />}
                              </View>
                              {deployments.length > 0 && (
                                <View style={S.card}>
                                  <Text style={S.cardTitle}>Deployments ({deployments.length})</Text>
                                  {deployments.map((dep: any, i: number) => (
                                    <View key={dep.id ?? i} style={S.depRow}>
                                      <View style={[S.depBadge, { backgroundColor: STATUS_COLOR[dep.deployment_status] ?? '#6B7280' }]}>
                                        <Text style={S.depBadgeTxt}>{dep.deployment_status}</Text>
                                      </View>
                                      <View style={{ flex: 1, marginLeft: 10 }}>
                                        <Text style={{ fontSize: 14, fontWeight: '600', color: '#1F2937' }}>{dep.unit_name ?? `Unit #${i + 1}`}</Text>
                                        {dep.eta_minutes != null && dep.deployment_status === 'EN_ROUTE' && (
                                          <Text style={{ fontSize: 12, color: '#6B7280', marginTop: 2 }}>ETA: {dep.eta_minutes} min</Text>
                                        )}
                                      </View>
                                    </View>
                                  ))}
                                </View>
                              )}
                            </>
                          )}
                        </View>
                      )}
                    </View>
                  );
                })}
              </>
            )}

            {resolvedDisasters.length > 0 && (
              <>
                <Text style={S.sectionLabel}>RESOLVED ({resolvedDisasters.length})</Text>
                {resolvedDisasters.map(d => (
                  <View key={d.id} style={[S.disasterCard, { opacity: 0.6 }]}>
                    <View style={[S.sevBar, { backgroundColor: d._falseAlarm ? '#6B7280' : '#22C55E' }]} />
                    <Text style={{ fontSize: 26, lineHeight: 34, marginRight: 10 }}>{TYPE_EMOJI[d.type] ?? '⚠️'}</Text>
                    <View style={{ flex: 1 }}>
                      <View style={S.titleRow}>
                        <Text style={S.dtype}>{(d.type ?? '').replace(/_/g, ' ')}</Text>
                        {d._falseAlarm ? (
                          <View style={S.falseBadge}><Text style={S.falseTxt}>FALSE ALARM</Text></View>
                        ) : (
                          <View style={[S.pill, { backgroundColor: '#22C55E20' }]}>
                            <Text style={[S.pillTxt, { color: '#22C55E' }]}>RESOLVED</Text>
                          </View>
                        )}
                      </View>
                      <Text style={S.daddr}>{d.location_address}</Text>
                      <Text style={S.dmeta}>{d.tracking_id}</Text>
                    </View>
                  </View>
                ))}
              </>
            )}
          </>
        )}

        {/* Reroute plans — load on demand */}
        <View style={{ paddingHorizontal: 16, paddingTop: 12 }}>
          <TouchableOpacity style={S.loadBtn} onPress={loadReroutePlans} disabled={rerouteLoading}>
            {rerouteLoading ? <ActivityIndicator color="#fff" size="small" /> : <Text style={S.loadBtnTxt}>Load Reroute Plans</Text>}
          </TouchableOpacity>
          {allReroutePlans.map((p: any, i: number) => (
            <View key={p.plan_id ?? i} style={[S.card, { marginTop: 8 }]}>
              <Text style={S.cardTitle}>Plan {p.plan_id ?? `#${i + 1}`}</Text>
              {p.impact_radius_km != null && <Row label="Radius" value={`${p.impact_radius_km} km`} />}
              <Row label="Routes" value={`${(p.chosen_routes ?? p.routes ?? []).length}`} />
            </View>
          ))}
        </View>

        <View style={{ height: 40 }} />
      </ScrollView>
    </SafeAreaView>
  );
};

const Row: React.FC<{ label: string; value: string }> = ({ label, value }) => (
  <Text style={{ fontSize: 13, color: '#6B7280', marginBottom: 4 }}>{label}: <Text style={{ color: '#1F2937', fontWeight: '600' }}>{value}</Text></Text>
);

const S = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#F8FAFC' },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', backgroundColor: RED, paddingHorizontal: 16, paddingVertical: 14 },
  headerTitle: { color: '#fff', fontSize: 17, fontWeight: '700' },
  hBtn: { width: 40, height: 40, justifyContent: 'center', alignItems: 'center' },
  sectionLabel: { fontSize: 11, fontWeight: '700', color: '#9CA3AF', letterSpacing: 0.8, paddingHorizontal: 16, paddingTop: 18, paddingBottom: 8 },
  disasterCard: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#fff', marginHorizontal: 12, marginBottom: 8, borderRadius: 12, padding: 12, overflow: 'hidden', shadowColor: '#000', shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.06, shadowRadius: 4, elevation: 2 },
  cardSelected: { borderWidth: 2, borderColor: RED },
  sevBar: { width: 4, height: '100%' as any, borderRadius: 2, marginRight: 10 },
  titleRow: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 3, flexWrap: 'wrap' },
  dtype: { fontSize: 15, fontWeight: '700', color: '#1F2937' },
  daddr: { fontSize: 12, color: '#6B7280', marginTop: 2 },
  dmeta: { fontSize: 11, color: '#9CA3AF', marginTop: 2 },
  pill: { paddingHorizontal: 7, paddingVertical: 2, borderRadius: 8 },
  pillTxt: { fontSize: 10, fontWeight: '800' },
  dot: { width: 10, height: 10, borderRadius: 5, marginLeft: 8 },
  falseBadge: { paddingHorizontal: 8, paddingVertical: 2, borderRadius: 8, backgroundColor: '#FEE2E2', borderWidth: 1, borderColor: '#EF4444' },
  falseTxt: { fontSize: 10, fontWeight: '800', color: '#EF4444' },
  detailBox: { marginHorizontal: 12, marginBottom: 8, borderLeftWidth: 2, borderLeftColor: '#DC262640', paddingLeft: 8 },
  card: { backgroundColor: '#fff', borderRadius: 12, padding: 14, marginBottom: 8, shadowColor: '#000', shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.05, shadowRadius: 3, elevation: 1 },
  cardTitle: { fontSize: 14, fontWeight: '700', color: '#1F2937', marginBottom: 10 },
  depRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 8 },
  depBadge: { paddingHorizontal: 8, paddingVertical: 3, borderRadius: 6 },
  depBadgeTxt: { color: '#fff', fontSize: 11, fontWeight: '700' },
  loadBtn: { backgroundColor: '#374151', borderRadius: 10, paddingVertical: 12, alignItems: 'center' },
  loadBtnTxt: { color: '#fff', fontWeight: '700', fontSize: 14 },
  emptyCard: { margin: 24, padding: 32, backgroundColor: '#fff', borderRadius: 16, alignItems: 'center' },
  emptyTitle: { fontSize: 18, fontWeight: '700', color: '#1F2937', marginTop: 12 },
  emptySub: { fontSize: 13, color: '#9CA3AF', textAlign: 'center', marginTop: 6 },
});

export default DisasterCommandScreen;